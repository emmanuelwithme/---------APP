/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swingguitest1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import com.mongodb.MongoClient;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import java.awt.Image;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import org.bson.conversions.Bson;
import javax.swing.ImageIcon;
import org.bson.Document;

/**
 *
 * @author wow90
 */
public class WeatherJFrame extends javax.swing.JFrame {

    /**
     * Creates new form WeatherJFrame
     */
    public WeatherJFrame() throws ParseException {
        initComponents();
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase db = mongoClient.getDatabase("test");
        MongoCollection<Document> collection = db.getCollection("weather");
        if (collection == null) {
            db.createCollection("weather");
            collection = db.getCollection("weather");
        }
        collection.drop();

//        把天氣資料從網站讀到MongoDB資料庫start
        String url1 = "https://opendata.cwb.gov.tw/api/v1/rest/datastore/F-D0047-091?Authorization=CWB-F62CC6E8-29C3-4036-B735-93EEAB2BE224&format=JSON&sort=time";
        InputStream stream = null;
        try {
            stream = new URL(url1).openStream();
        } catch (MalformedURLException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        JSONObject json = null;
        try {
            json = readJSONFromStream(stream, "UTF-8");
        } catch (UnsupportedEncodingException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        JSONArray location = json.getJSONObject("records").getJSONArray("locations").getJSONObject(0).getJSONArray("location");
        for (int i = 0; i < location.length(); i++) {
            Document document = new Document();
            document.append("地點", location.getJSONObject(i).getString("locationName"));
            document.append("weatherElement", location.getJSONObject(i).getJSONArray("weatherElement").toList());
            collection.insertOne(document);
        }
//        把天氣資料從網站讀到MongoDB資料庫end

//      把地點從資料庫一一加到jComboBox1下拉式選單start
        Bson filter = new Document();
        Bson project = and(eq("地點", 1L), eq("_id", 0L));
        FindIterable<Document> result = collection.find(filter).projection(project);
        for (Document d : result) {
            System.out.println(d.getString("地點"));
            jComboBox1.addItem(d.getString("地點"));
        }
//      把地點從資料庫一一加到jComboBox1下拉式選單end

//      把日期從資料庫讀出來存在startDate1、endDate1
        Date startDate1 = null;
        Date endDate1 = null;
        AggregateIterable<Document> result_ag = collection.aggregate(Arrays.asList(new Document("$match",
                new Document("地點", "新竹縣")),
                new Document("$project",
                        new Document("_id", 0L)
                                .append("weatherElement",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement", 0L)))),
                new Document("$project",
                        new Document("weatherElement",
                                new Document("$arrayElemAt", Arrays.asList("$weatherElement.time", 0L))))));
        for (Document d : result_ag) {
            Document d1 = (Document) d.get("weatherElement");
            System.out.println(d1.get("startTime"));
            System.out.println(d1.get("endTime"));
            String startDate;
            startDate = d1.getString("startTime");
            startDate1 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(startDate);
            System.out.println(startDate1);
        }
        result_ag = collection.aggregate(Arrays.asList(new Document("$match",
                new Document("地點", "新竹縣")),
                new Document("$project",
                        new Document("_id", 0L)
                                .append("weatherElement",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement", 0L)))),
                new Document("$project",
                        new Document("weatherElement",
                                new Document("$arrayElemAt", Arrays.asList("$weatherElement.time", -1L))))));
        for (Document d : result_ag) {
            Document d1 = (Document) d.get("weatherElement");
            System.out.println(d1.get("startTime"));
            System.out.println(d1.get("endTime"));
            String endDate;
            endDate = d1.getString("endTime");
            endDate1 = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss").parse(endDate);
            System.out.println(endDate1);
        }

//        把日期按鈕從startDate1到endDate1每一天做成一個按鈕
        this.jButtonDate = new ArrayList<javax.swing.JButton>();//jButtonDate是一個ArrayList裡面存很多日期JButton
        jButtonDate.add(jButton1);
        jButtonDate.add(jButton2);
        jButtonDate.add(jButton3);
        jButtonDate.add(jButton4);
        jButtonDate.add(jButton5);
        jButtonDate.add(jButton6);
        jButtonDate.add(jButton7);
        jButtonDate.add(jButton8);
        int index_date = 0;
//        endDate1.setTime(endDate1.getTime() + 86400000);//多加一天(!!!!!!!!!!!!!!有問題)
        for (Date nowDate1 = startDate1; nowDate1.before(endDate1); nowDate1.setTime(nowDate1.getTime() + 86400000)) {
            //nowDate1每次加一天，設定成btn文字
            String s = new SimpleDateFormat("yyyy-MM-dd E").format(nowDate1);
            jButtonDate.get(index_date).setText(s);
            index_date++;
        }

//        把00到24時每個按鈕做出來
        this.jButtonHour = new ArrayList<javax.swing.JButton>();//jButtonHour是一個ArrayList裡面存很多時間JButton
        jButtonHour.add(jButton9);
        jButtonHour.add(jButton10);
        jButtonHour.add(jButton11);
        jButtonHour.add(jButton12);
        jButtonHour.add(jButton13);
        jButtonHour.add(jButton14);
        jButtonHour.add(jButton15);
        jButtonHour.add(jButton16);
        jButtonHour.add(jButton17);
        jButtonHour.add(jButton18);
        jButtonHour.add(jButton19);
        jButtonHour.add(jButton20);
        jButtonHour.add(jButton21);
        jButtonHour.add(jButton22);
        jButtonHour.add(jButton23);
        jButtonHour.add(jButton24);
        jButtonHour.add(jButton25);
        jButtonHour.add(jButton26);
        jButtonHour.add(jButton27);
        jButtonHour.add(jButton28);
        jButtonHour.add(jButton29);
        jButtonHour.add(jButton30);
        jButtonHour.add(jButton31);
        jButtonHour.add(jButton32);
        for (int i = 0; i < jButtonHour.size(); i++) {
            jButtonHour.get(i).setText(String.format("%02d%s", i, "時"));
        }

        mongoClient.close();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jComboBox1 = new javax.swing.JComboBox<>();
        jPanel7 = new javax.swing.JPanel();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();
        jButton25 = new javax.swing.JButton();
        jButton26 = new javax.swing.JButton();
        jButton27 = new javax.swing.JButton();
        jButton28 = new javax.swing.JButton();
        jButton29 = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        jButton31 = new javax.swing.JButton();
        jButton32 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("地名:");

        jLabel2.setText("星期幾 幾點");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setText("jLabel3");
        jLabel3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel4.setText("jLabel4");
        jLabel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel5.setText("jLabel5");
        jLabel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel6.setText("jLabel6");
        jLabel6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel7.setText("jLabel7");
        jLabel7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap())))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(25, 25, 25))
        );

        jLabel8.setText("天氣現象圖示");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
        );

        jLabel9.setText("jLabel9");
        jLabel9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel10.setText("jLabel10");
        jLabel10.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel11.setText("jLabel11");
        jLabel11.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel12.setText("jLabel12");
        jLabel12.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel13.setText("jLabel13");
        jLabel13.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel14.setText("jLabel14");
        jLabel14.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel15.setText("jLabel15");
        jLabel15.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel16.setText("jLabel16");
        jLabel16.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        jLabel17.setText("jLabel17");
        jLabel17.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jButton1.setText("2022-01-16 週日");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("2022-01-16 週日");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("2022-01-16 週日");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setText("2022-01-16 週日");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setText("2022-01-16 週日");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        jButton6.setText("2022-01-16 週日");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });

        jButton7.setText("2022-01-16 週日");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });

        jButton8.setText("2022-01-16 週日");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton8)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton1)
                .addComponent(jButton2)
                .addComponent(jButton3)
                .addComponent(jButton4)
                .addComponent(jButton5)
                .addComponent(jButton6)
                .addComponent(jButton7)
                .addComponent(jButton8))
        );

        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });

        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });

        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });

        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });

        jButton13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton13ActionPerformed(evt);
            }
        });

        jButton14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton14ActionPerformed(evt);
            }
        });

        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });

        jButton16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton16ActionPerformed(evt);
            }
        });

        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });

        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addComponent(jButton9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton14)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton15)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton17)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton20)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(jButton10)
                .addComponent(jButton11)
                .addComponent(jButton9)
                .addComponent(jButton12)
                .addComponent(jButton13)
                .addComponent(jButton14)
                .addComponent(jButton15)
                .addComponent(jButton16)
                .addComponent(jButton17)
                .addComponent(jButton18)
                .addComponent(jButton19))
            .addComponent(jButton20)
        );

        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });

        jButton23.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton23ActionPerformed(evt);
            }
        });

        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });

        jButton25.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton25ActionPerformed(evt);
            }
        });

        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });

        jButton27.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton27ActionPerformed(evt);
            }
        });

        jButton28.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton28ActionPerformed(evt);
            }
        });

        jButton29.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton29ActionPerformed(evt);
            }
        });

        jButton30.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton30ActionPerformed(evt);
            }
        });

        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        jButton32.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton32ActionPerformed(evt);
            }
        });

        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jButton21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton23)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton24)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton25)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton26)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton27)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton28)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton29)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton32)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton22)
                    .addComponent(jButton23)
                    .addComponent(jButton24)
                    .addComponent(jButton25)
                    .addComponent(jButton26)
                    .addComponent(jButton27)
                    .addComponent(jButton28)
                    .addComponent(jButton29)
                    .addComponent(jButton30)
                    .addComponent(jButton31)
                    .addComponent(jButton32)
                    .addComponent(jButton21))
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel18.setText("天氣現象:");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addComponent(jLabel18)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 93, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(2, 2, 2))
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
            .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(106, 106, 106)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(139, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        setjButtonHourDisableStart();
        s_date = this.jButton1.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton10.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton2.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton3.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton9.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton4.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton5.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton6.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        setjButtonHourEnable();
        s_date = this.jButton7.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        setjButtonHourDisableEnd();
        s_date = this.jButton8.getText();
        System.out.println(s_date);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton11.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton12.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jButton13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton13ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton13.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton13ActionPerformed

    private void jButton14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton14ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton14.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton14ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton15.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton16ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton16.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton16ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton17.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton18.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton19.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton20.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton21.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton22.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton23ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton23ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton23.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton23ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton24.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton25ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton25ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton25.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton25ActionPerformed

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton26.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton27ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton27ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton27.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton27ActionPerformed

    private void jButton28ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton28ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton28.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton28ActionPerformed

    private void jButton29ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton29ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton29.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton29ActionPerformed

    private void jButton30ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton30ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton30.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton30ActionPerformed

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton31.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton31ActionPerformed

    private void jButton32ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton32ActionPerformed
        // TODO add your handling code here:
        s_hour = this.jButton32.getText();
        System.out.println(s_hour);
        dateChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton32ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        s_location = jComboBox1.getSelectedItem().toString();
        System.out.println(s_location);
        locationChange();
        try {
            if (isReadyToQuery()) {
                MongoDBQuery();
            }
        } catch (ParseException ex) {
            Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jComboBox1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(WeatherJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(WeatherJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(WeatherJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(WeatherJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    WeatherJFrame wjf = new WeatherJFrame();
                    wjf.setVisible(true);
                } catch (ParseException ex) {
                    Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    public static JSONObject readJSONFromStream(InputStream stream, String encoding) throws UnsupportedEncodingException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, encoding));
        try {
            return new JSONObject(new JSONTokener(reader));
        } catch (JSONException e) {
            //some exception handler code.
            return null;
        }
    }
    List<javax.swing.JButton> jButtonDate;
    List<javax.swing.JButton> jButtonHour;
    String s_date, s_hour, s_location;
    Date date;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton25;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton27;
    private javax.swing.JButton jButton28;
    private javax.swing.JButton jButton29;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JButton jButton32;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    // End of variables declaration//GEN-END:variables

    private void dateChange() {//在螢幕上改變顯示時間
//        s_hour = s_hour.substring(0, s_hour.length() - 1);//s_hour(時)變成只有2位數字
        jLabel2.setText(s_date + s_hour);
    }

    private void locationChange() {
        jLabel1.setText("地點:" + s_location);
    }

    private boolean isReadyToQuery() throws ParseException {
        if (s_date != null && s_hour != null && s_location != null) {
            date = new SimpleDateFormat("yyyy-MM-dd E-hh時").parse(s_date + '-' + s_hour);
            System.out.println(date);
            return true;
        } else {
            return false;
        }
    }

    private void MongoDBQuery() {
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase database = mongoClient.getDatabase("test");
        MongoCollection<Document> collection = database.getCollection("weather");

        AggregateIterable<Document> result = collection.aggregate(Arrays.asList(new Document("$match",
                new Document("地點", s_location)),
                new Document("$unwind",
                        new Document("path", "$weatherElement")
                                .append("includeArrayIndex", "ArrayIndex")),
                new Document("$unwind",
                        new Document("path", "$weatherElement.time")
                                .append("includeArrayIndex", "ArrayIndex")),
                new Document("$project",
                        new Document("startime",
                                new Document("$dateFromString",
                                        new Document("dateString", "$weatherElement.time.startTime")
                                                .append("format", "%Y-%m-%d %H:%M:%S")))
                                .append("endTime",
                                        new Document("$dateFromString",
                                                new Document("dateString", "$weatherElement.time.endTime")
                                                        .append("format", "%Y-%m-%d %H:%M:%S")))
                                .append("description", "$weatherElement.description")
                                .append("value",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement.time.elementValue", 0L)))),
                new Document("$project",
                        new Document("startime", 1L)
                                .append("endTime", 1L)
                                .append("description", 1L)
                                .append("value", "$value.value")
                                .append("measures", "$value.measures")),
                new Document("$match",
                        new Document("startime",
                                new Document("$lte",
                                        new java.util.Date((date.getTime() + 28800000) + 'L')))
                                .append("endTime",
                                        new Document("$gt",
                                                new java.util.Date((date.getTime() + 28800000) + 'L'))))));
        System.out.println(date.getTime() + 28800000);//mongoDB要+8小時(28800000毫秒)，且字串必須加上L，因為是用ISODate
        System.out.println(new java.util.Date(date.getTime() + 'L'));
        for (Document d : result) {
            System.out.print(d.getString("description"));
            System.out.print(d.getString("value"));
            System.out.println(d.getString("measures"));
            switch (d.getString("description")) {
                case "12小時降雨機率":
                    jLabel3.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "平均溫度":
                    jLabel4.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "平均相對濕度":
                    jLabel5.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "天氣現象":
                    jLabel6.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "天氣預報綜合描述":
                    jLabel7.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最低溫度":
                    jLabel9.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最高溫度":
                    jLabel10.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最低體感溫度":
                    jLabel11.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最高體感溫度":
                    jLabel12.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "平均露點溫度":
                    jLabel13.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最小舒適度指數":
                    jLabel14.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最大舒適度指數":
                    jLabel15.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "風向":
                    jLabel16.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
                case "最大風速":
                    jLabel17.setText(d.getString("description") + ':' + ' ' + d.getString("value") + d.getString("measures"));
                    break;
            }
        }

//        找出Wx，並用weatherElement.time.elementValue.1.value(&measures)判斷顯示天氣現象圖片
        result = collection.aggregate(Arrays.asList(new Document("$match",
                new Document("地點", s_location)),
                new Document("$unwind",
                        new Document("path", "$weatherElement")
                                .append("includeArrayIndex", "ArrayIndex")
                                .append("preserveNullAndEmptyArrays", true)),
                new Document("$match",
                        new Document("ArrayIndex", 6L)),
                new Document("$unwind",
                        new Document("path", "$weatherElement.time")
                                .append("includeArrayIndex", "ArrayIndex")
                                .append("preserveNullAndEmptyArrays", true)),
                new Document("$project",
                        new Document("startTime",
                                new Document("$dateFromString",
                                        new Document("dateString", "$weatherElement.time.startTime")
                                                .append("format", "%Y-%m-%d %H:%M:%S")))
                                .append("endTime",
                                        new Document("$dateFromString",
                                                new Document("dateString", "$weatherElement.time.endTime")
                                                        .append("format", "%Y-%m-%d %H:%M:%S")))
                                .append("value",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement.time.elementValue.value", 1L)))
                                .append("measures",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement.time.elementValue.measures", 1L)))
                                .append("description",
                                        new Document("$arrayElemAt", Arrays.asList("$weatherElement.time.elementValue.value", 0L)))),
                new Document("$match",
                        new Document("startTime",
                                new Document("$lte",
                                        new java.util.Date((date.getTime() + 28800000) + 'L')))
                                .append("endTime",
                                        new Document("$gt",
                                                new java.util.Date((date.getTime() + 28800000) + 'L'))))));
        for (Document d : result) {
            ImageIcon imageIcon = new ImageIcon("src/swingguitest1/img_jpg/" + String.format("%02d", Integer.parseInt(d.getString("value"))) + ".jpg"); // load the image to a imageIcon
            Image image = imageIcon.getImage(); // transform it 
            Image newimg = image.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH); // scale it the smooth way  
            imageIcon = new ImageIcon(newimg);  // transform it back
            jLabel8.setIcon(imageIcon);
            jLabel8.setText(null);
            jLabel18.setText(d.getString("description"));
        }
        mongoClient.close();
    }

    private void setjButtonHourDisableStart() {
        this.jButtonHour = new ArrayList<javax.swing.JButton>();//jButtonHour是一個ArrayList裡面存很多時間JButton
        jButtonHour.add(jButton9);
        jButtonHour.add(jButton10);
        jButtonHour.add(jButton11);
        jButtonHour.add(jButton12);
        jButtonHour.add(jButton13);
        jButtonHour.add(jButton14);
        jButtonHour.add(jButton15);
        jButtonHour.add(jButton16);
        jButtonHour.add(jButton17);
        jButtonHour.add(jButton18);
        jButtonHour.add(jButton19);
        jButtonHour.add(jButton20);
        jButtonHour.add(jButton21);
        jButtonHour.add(jButton22);
        jButtonHour.add(jButton23);
        jButtonHour.add(jButton24);
        jButtonHour.add(jButton25);
        jButtonHour.add(jButton26);
        jButtonHour.add(jButton27);
        jButtonHour.add(jButton28);
        jButtonHour.add(jButton29);
        jButtonHour.add(jButton30);
        jButtonHour.add(jButton31);
        jButtonHour.add(jButton32);
        for (int i = 0; i < jButtonHour.size(); i++) {
            jButtonHour.get(i).setEnabled(true);//每個按鈕先弄成可以按
        }
        for (int i = 0; i < jButtonHour.size(); i++) {
            System.out.println(jButtonHour.get(i).getText().substring(0, jButtonHour.get(i).getText().length() - 1));//00 01  02  ......  23
//            如果小時按鈕上的小時數<現在時間的小時數
            if (Integer.parseInt(jButtonHour.get(i).getText().substring(0, jButtonHour.get(i).getText().length() - 1)) < new Date().getHours()) {
                jButtonHour.get(i).setEnabled(false);//把按鈕設成不能按
            }
        }
    }

    private void setjButtonHourEnable() {
        this.jButtonHour = new ArrayList<javax.swing.JButton>();//jButtonHour是一個ArrayList裡面存很多時間JButton
        jButtonHour.add(jButton9);
        jButtonHour.add(jButton10);
        jButtonHour.add(jButton11);
        jButtonHour.add(jButton12);
        jButtonHour.add(jButton13);
        jButtonHour.add(jButton14);
        jButtonHour.add(jButton15);
        jButtonHour.add(jButton16);
        jButtonHour.add(jButton17);
        jButtonHour.add(jButton18);
        jButtonHour.add(jButton19);
        jButtonHour.add(jButton20);
        jButtonHour.add(jButton21);
        jButtonHour.add(jButton22);
        jButtonHour.add(jButton23);
        jButtonHour.add(jButton24);
        jButtonHour.add(jButton25);
        jButtonHour.add(jButton26);
        jButtonHour.add(jButton27);
        jButtonHour.add(jButton28);
        jButtonHour.add(jButton29);
        jButtonHour.add(jButton30);
        jButtonHour.add(jButton31);
        jButtonHour.add(jButton32);
        for (int i = 0; i < jButtonHour.size(); i++) {
            jButtonHour.get(i).setEnabled(true);
        }
    }

    private void setjButtonHourDisableEnd() {
//        (!有問題)
        MongoClient mongoClient = new MongoClient("localhost", 27017);
        MongoDatabase database = mongoClient.getDatabase("test");
        MongoCollection<Document> collection = database.getCollection("weather");
        AggregateIterable<Document> result = collection.aggregate(Arrays.asList(new Document("$match",
                new Document("地點", "新竹縣")),
                new Document("$project",
                        new Document("weatherElement",
                                new Document("$arrayElemAt", Arrays.asList("$weatherElement", 0L)))),
                new Document("$project",
                        new Document("time",
                                new Document("$arrayElemAt", Arrays.asList("$weatherElement.time", -1L)))),
                new Document("$project",
                        new Document("_id", 0L)
                                .append("startTime", "$time.startTime")
                                .append("endTime", "$time.endTime"))));
        Date endDate = null;
        for (Document d : result) {
            try {
                endDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(d.getString("endTime"));
                System.out.println(endDate);
            } catch (ParseException ex) {
                Logger.getLogger(WeatherJFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        this.jButtonHour = new ArrayList<javax.swing.JButton>();//jButtonHour是一個ArrayList裡面存很多時間JButton
        jButtonHour.add(jButton9);
        jButtonHour.add(jButton10);
        jButtonHour.add(jButton11);
        jButtonHour.add(jButton12);
        jButtonHour.add(jButton13);
        jButtonHour.add(jButton14);
        jButtonHour.add(jButton15);
        jButtonHour.add(jButton16);
        jButtonHour.add(jButton17);
        jButtonHour.add(jButton18);
        jButtonHour.add(jButton19);
        jButtonHour.add(jButton20);
        jButtonHour.add(jButton21);
        jButtonHour.add(jButton22);
        jButtonHour.add(jButton23);
        jButtonHour.add(jButton24);
        jButtonHour.add(jButton25);
        jButtonHour.add(jButton26);
        jButtonHour.add(jButton27);
        jButtonHour.add(jButton28);
        jButtonHour.add(jButton29);
        jButtonHour.add(jButton30);
        jButtonHour.add(jButton31);
        jButtonHour.add(jButton32);
        for (int i = 0; i < jButtonHour.size(); i++) {
            jButtonHour.get(i).setEnabled(true);
        }
        for (int i = 0; i < jButtonHour.size(); i++) {
            System.out.println(jButtonHour.get(i).getText().substring(0, jButtonHour.get(i).getText().length() - 1));//00 01  02  ......  23
            if (Integer.parseInt(jButtonHour.get(i).getText().substring(0, jButtonHour.get(i).getText().length() - 1)) > endDate.getHours() - 1) {
                /*
                當按鈕上的小時數>get資料庫裡最後一個時間小時數-1 => 按鈕setEnabled(false)。
                get資料庫裡最後一個時間小時數-1，是因為我在query資料庫的時候是:
                {
                  startime:{$lte:ISODate("按鈕時間")},
                  endTime:{$gt:ISODate("按鈕時間")}
                }
                也就是按鈕時間會>=startime，且<endTime
                 */
                jButtonHour.get(i).setEnabled(false);
            }
        }
        mongoClient.close();
    }
}
